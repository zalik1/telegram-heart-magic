# telegram-heart-magic
 Animated magic heart in your Telegram dialog! | Анимированное волшебное сердечко в вашем диалоге Telegram!
 
 # Magic Heart
Sends a magic heart to the current dialog in Telegram | Отправляет волшебное сердечко в текущий диалог в Telegram 

# Instalation | Установка
```
$ pip3 install telethon
```

# Run | Запуск
```
$ python3 magic_heart.py
```
Login in your telegram account and send "magic" in dialog | Войдите в свой аккаунт Telegram и отправьте "magic" в диалоговом окне



# Video example | Видео пример

$ https://youtu.be/8kThuxuQVW4